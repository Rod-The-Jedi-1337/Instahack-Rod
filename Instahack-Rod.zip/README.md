# Instahack

<p align="center">
  <img src="https://img.shields.io/badge/Version-1.0-green?style=for-the-badge">
  <img src="https://img.shields.io/github/license/HackWeiser360/Instahack?style=for-the-badge">
  <img src="https://img.shields.io/github/stars/HackWeiser360/Instahack?style=for-the-badge">
  <img src="https://img.shields.io/github/issues/HackWeiser360/Instahack?color=red&style=for-the-badge">
  <img src="https://img.shields.io/github/forks/HackWeiser360/Instahack?color=teal&style=for-the-badge">
  <img src="https://img.shields.io/badge/Author-HackWeiser360-cyan?style=flat-square">
  <img src="https://img.shields.io/badge/Open%20Source-Yes-cyan?style=flat-square">
  <img src="https://img.shields.io/badge/MADE%20IN-Kenya✌-green?colorA=%23ff0000&colorB=%23017e40&style=flat-square">
  <img src="https://img.shields.io/badge/Written%20In-Shell-cyan?style=flat-square">
</p>

Instahack is a Shell based script for hacking Instagram accounts using the Bruteforce method. It has its own passwords but you can add yours using nano. 
Instahack is Available for Termux and Parrot Os

***
## [+] Installation and Usage

$ apt-get install tor

$ git clone https://github.com/HackWeiser360/Instahack

$ cd Instahack

$ chmod +x insta.sh

$ ./insta.sh

***

## Where to find us
<div align="center">
<a href="https://github.com/HackWeiser360" target="_blank">
<img src=https://img.shields.io/badge/github-%2324292e.svg?&style=for-the-badge&logo=github&logoColor=white alt=github style="margin-bottom: 5px;" />
</a>
<a href="https://twitter.com/503_madmax" target="_blank">
<img src=https://img.shields.io/badge/twitter-%2300acee.svg?&style=for-the-badge&logo=twitter&logoColor=white alt=twitter style="margin-bottom: 5px;" />
</a>
<a href="https://www.instagram.com/madmax4708/" target="_blank">
<img src=https://img.shields.io/badge/instagram-%23000000.svg?&style=for-the-badge&logo=instagram&logoColor=white alt=instagram style="margin-bottom: 5px;" />

[![github-readme-twitter](https://github-readme-twitter.gazf.vercel.app/api?id=503_madmax)](https://github.com/HackWeiser360/github-readme-twitter)

### Stargazers
[![Stargazers repo roster for @HackWeiser360/Instahack](https://reporoster.com/stars/HackWeiser360/Instahack)](https://github.com/HackWeiser360/Instahack)
